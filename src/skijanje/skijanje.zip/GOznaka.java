package skijanje;

public class GOznaka extends Exception {

	public GOznaka(String s) {
		super(s);
	}
	
}
